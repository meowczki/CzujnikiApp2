package ib.edu.czujnikiapp;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Date;

public class MainActivity extends AppCompatActivity implements SensorEventListener {


    private SensorManager sensorManager;
    private Sensor accelerometr;
    private Sensor gyroscope;
    private  boolean isRunning=false;
    private static final float NS2S=1.0e-9f;
    public static float timeStamp;
    private TextView tvAx,tvAy, tvAz;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager=(SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometr=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        //gyroscope=sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        sensorManager.registerListener(this,accelerometr,SensorManager.SENSOR_DELAY_FASTEST);

        tvAx=(TextView) findViewById(R.id.axValue);
        tvAy=(TextView) findViewById(R.id.ayValue);
        tvAz=(TextView) findViewById(R.id.azValue);



    }
    public void startOnClick(View view){
        isRunning=!isRunning;

      TextView samplesTv=(TextView)findViewById(R.id.samplesTv);
      TextView timeTv=(TextView)findViewById(R.id.timeTv);
      samplesTv.setText(Double.toString(1/timeStamp));
      timeStamp=0;

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {


        if (isRunning){

            Sensor test=sensorEvent.sensor;
            int sensorType=test.getType();

            if (sensorType == Sensor.TYPE_ACCELEROMETER){
                float ax= sensorEvent.values[0];
                float ay= sensorEvent.values[1];
                float az= sensorEvent.values[2];
               timeStamp=sensorEvent.timestamp*NS2S;

                tvAx.setText(Float.toString(ax));
                tvAy.setText(Float.toString(ay));
                tvAz.setText(Float.toString(az));

            }




        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
